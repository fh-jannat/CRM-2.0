export const APPLICATION = '/application';
