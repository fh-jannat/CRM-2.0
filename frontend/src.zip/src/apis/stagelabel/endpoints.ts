export const STAGELABEL = '/stagelabel';
