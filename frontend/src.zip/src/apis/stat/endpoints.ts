export const STAT = '/stat';
