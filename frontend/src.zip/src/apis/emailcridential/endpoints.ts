export const EMIALCRIDENTIAL = '/mail';
