export const METACRIDENTIAL = '/facebook';
