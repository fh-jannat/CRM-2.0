export const NOTIFICATIONS = '/notification';
