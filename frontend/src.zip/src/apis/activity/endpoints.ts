export const ACTIVITY = '/activity';
