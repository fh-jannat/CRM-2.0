export * from './antd-theme';
